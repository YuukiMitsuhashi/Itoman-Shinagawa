# Swim AI Pro

This is a multi-file replacement for the single-HTML prototype.

## What it is designed to do

1. Paste a YouTube URL.
2. Inspect the video metadata.
3. Choose the exact start/end interval.
4. Extract only that interval on the backend.
5. Detect multiple swimmers with high-resolution tiled inference.
6. Track the selected swimmer over time.
7. Use enlarged crops for pose estimation because swimmers may occupy only a small part of a 1080p frame.
8. Support wall geometry that changes over time:
   - Wall A and Wall B
   - multiple keyframes
   - independent angles
   - interpolation between keyframes
9. Analyze stroke/race distance and export results.

## Install

You need Python 3.10+ and FFmpeg installed and available on PATH.

```bash
cd swim_ai_pro
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn backend.main:app --reload
```

Open http://127.0.0.1:8000

On the first AI run, Ultralytics may download the selected model weights.

## Making the AI substantially stronger

The current `ai_pipeline.py` is intentionally modular. For a genuinely high-end swimming analyzer, the next upgrades should be:

- YOLO pose model at 1280/1536 input size.
- SAHI-style tiled inference for tiny swimmers.
- BoT-SORT with appearance/ReID embeddings.
- ByteTrack fallback when appearance is unreliable.
- Optical-flow prediction between detector frames.
- Dedicated swimmer ReID embedding rather than generic person ReID.
- A temporal transformer trained on swimming clips for stroke classification.
- Separate turn/touch classifier using 1–2 seconds before and after the wall.
- Camera-motion estimation with feature matching + homography.
- Time-varying wall keyframes.
- Automatic lane-line/wall detection as a second geometry cue.
- Confidence fusion across detector, tracker, pose and geometry.
- Manual correction of a track/turn followed by re-analysis.

### Important accuracy note

Do not treat the scaffold's split values as competition timing. It deliberately avoids pretending that pixel displacement equals meters until camera geometry is calibrated. The right architecture is to make calibration a first-class part of the analysis.

## YouTube

The backend uses `yt-dlp` to inspect/extract the source. Use it only for videos you are permitted to access/download and in accordance with the applicable platform terms and copyright rules.
